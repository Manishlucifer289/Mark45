package com.mark45;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mark45ApplicationTests {

	@Test
	void contextLoads() {
	}

}
