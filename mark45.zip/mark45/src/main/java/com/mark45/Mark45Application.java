package com.mark45;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mark45Application {

	public static void main(String[] args) {
		SpringApplication.run(Mark45Application.class, args);
	}

}
